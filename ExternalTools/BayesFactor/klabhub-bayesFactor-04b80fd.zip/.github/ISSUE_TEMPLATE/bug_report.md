---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.


**To Reproduce**
Steps to reproduce the behavior:  Paste your code here.

** Versions:**
 - Matlab version: 


**Screenshots**
If applicable, copy Matlab's error messages here to help explain your problem.
